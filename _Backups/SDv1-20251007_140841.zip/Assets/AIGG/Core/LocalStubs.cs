namespace Aim2Pro.AIGG.Local
{
    // Minimal shim so WorkbenchWindow compiles.
    public static class NL
    {
        public static string Normalize(string s) => s;
    }
}
